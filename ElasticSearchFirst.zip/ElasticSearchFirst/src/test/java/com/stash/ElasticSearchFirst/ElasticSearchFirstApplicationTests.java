package com.stash.ElasticSearchFirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticSearchFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
