package com.stash.ElasticSearchFirst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElasticSearchFirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElasticSearchFirstApplication.class, args);
	}

}
